<?php

header("Location: user/index.php");