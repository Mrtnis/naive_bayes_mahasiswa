<?php
// Create connection
// $koneksi = mysqli_connect("localhost", "root", "", "naive_bayes_revisi");
$koneksi = mysqli_connect("localhost", "root", "", "klasifikasi_nb");