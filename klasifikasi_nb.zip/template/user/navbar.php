<nav class="navbar navbar-light py-4">
  <div class="container wrap-header">
    <a class="link-brand" href="<?= $base_url ?>"><span class="mb-0 h3 fw-bolder text-brand">Klasifikasi Tingkat Pemahaman Mahasiswa Terhadap Matakuliah Selama Pembelajaran Daring Menggunakan Algoritma Naive Bayes</span></a>
  </div>
</nav>
<div class="container">
  <hr>
</div>
