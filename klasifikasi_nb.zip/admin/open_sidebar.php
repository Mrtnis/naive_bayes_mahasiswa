<div class="mx-5">
  <div class="row mb-5">
    <div class="col-md-3">
      <?php include_once '../template/admin/sidebar.php'; ?>
    </div>
    <div class="col-md-9">
      <div class="card body-element shadow">